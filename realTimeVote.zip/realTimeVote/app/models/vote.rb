class Vote < ActiveRecord::Base
	belongs_to :language
end
