require 'test_helper'

class BrightIdeaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
